const APPROVED_PUBLIC_ORIGIN = 'https://virtcruise.airwide.co.uk';
const APPROVED_API_ORIGINS = new Set(['https://api.virtcruise.airwide.co.uk']);

function exactOrigin(value, name) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${name} is required`);
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/'
      || url.search || url.hash) throw new Error(`${name} must be an HTTPS origin`);
  return url.origin;
}

export function validateRuntimeConfig(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('VirtCruise public runtime configuration is required');
  }
  const publicOrigin = exactOrigin(value.publicOrigin, 'publicOrigin');
  const apiOrigin = exactOrigin(value.apiOrigin, 'apiOrigin');
  if (publicOrigin !== APPROVED_PUBLIC_ORIGIN) throw new Error('publicOrigin is not approved');
  if (!APPROVED_API_ORIGINS.has(apiOrigin)) throw new Error('apiOrigin is not approved');
  if (typeof value.dynamicCatalogueEnabled !== 'boolean') {
    throw new Error('dynamicCatalogueEnabled must be a boolean');
  }
  return Object.freeze({ publicOrigin, apiOrigin, dynamicCatalogueEnabled: value.dynamicCatalogueEnabled });
}

// This is the single, non-secret production deployment boundary. Artifact generation
// the production-beta build copies it with development runtime paths removed.
export const runtimeConfig = validateRuntimeConfig({
  publicOrigin: APPROVED_PUBLIC_ORIGIN,
  apiOrigin: 'https://api.virtcruise.airwide.co.uk',
  dynamicCatalogueEnabled: true
});

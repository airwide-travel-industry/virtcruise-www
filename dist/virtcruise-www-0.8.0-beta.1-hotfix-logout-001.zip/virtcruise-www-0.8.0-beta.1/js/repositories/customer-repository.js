export function createCustomerRepository({ request }) {
  return {
    create: payload => request('/api/v1/customers', { method: 'POST', body: JSON.stringify(payload) }),
    get: customerId => request(`/api/v1/customers/${encodeURIComponent(customerId)}`),
    lookupByEmail: email => request(`/api/v1/customers/lookup?email=${encodeURIComponent(email)}`),
    update: (customerId, payload) => request(`/api/v1/customers/${encodeURIComponent(customerId)}`, {
      method: 'PUT', body: JSON.stringify(payload)
    }),
    remove: customerId => request(`/api/v1/customers/${encodeURIComponent(customerId)}`, { method: 'DELETE' })
  };
}

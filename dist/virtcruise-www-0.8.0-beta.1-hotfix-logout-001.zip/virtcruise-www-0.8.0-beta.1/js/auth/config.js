import { runtimeConfig } from '../runtime-config.js';

const siteBasePath = new URL('../../', import.meta.url).pathname.replace(/\/+$/, '');

export const authRuntime = Object.freeze({
  mode: 'production',
  apiBaseUrl: runtimeConfig.apiOrigin
});

export function authPageUrl(path, parameters = {}) {
  const relativePath = String(path || '/').replace(/^\/+/, '');
  const url = new URL(`${siteBasePath}/${relativePath}`, window.location.origin);
  Object.entries(parameters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, value);
  });
  return `${url.pathname}${url.search}${url.hash}`;
}

export function safeReturnPath(value, fallback = '/account/') {
  if (!value) return fallback;
  try {
    const url = new URL(value, window.location.origin);
    return url.origin === window.location.origin && url.pathname.startsWith('/')
      ? `${url.pathname}${url.search}${url.hash}`
      : fallback;
  } catch {
    return fallback;
  }
}
